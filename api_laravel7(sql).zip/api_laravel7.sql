-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2021 at 04:20 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `api_laravel7`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double(8,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `description`, `price`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Omnis illo asperiores sunt dicta aut.', 'Aut consequatur mollitia necessitatibus. Nulla minima est corrupti adipisci quia vitae quia. Et repellendus at et dolor autem aut dolores qui.', 7971.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(2, 'Mollitia consectetur perspiciatis est non nisi sed.', 'Nisi tempore fuga commodi accusantium. Excepturi quaerat exercitationem animi ea facilis. Natus dignissimos ut rerum culpa atque expedita.', 2620.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(3, 'Dignissimos facere esse molestiae quasi.', 'Blanditiis soluta sint dolor et aliquid non inventore. Repudiandae natus aut id unde sint aspernatur laborum. Enim nihil mollitia omnis.', 9673.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(4, 'Doloribus perferendis perspiciatis quis optio excepturi.', 'Quis et aliquam et aliquid neque praesentium laudantium quia. Qui dicta reiciendis officia quod tempore fugiat sunt. Deserunt fuga similique unde. Sit molestiae eos vel placeat similique quasi.', 313.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(5, 'Pariatur officiis accusantium sunt aut.', 'Totam sit et quia voluptatem rerum earum. Voluptatibus officia assumenda velit sapiente ut ipsum. Maxime et temporibus voluptas dolor ab ipsum. Maiores rerum aperiam iste nisi.', 93.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(6, 'Molestiae et necessitatibus velit suscipit.', 'Quia modi nam quaerat ea veritatis nam qui. Omnis mollitia voluptas repellat ea qui iure ut. Maxime et voluptates ducimus sit maiores nesciunt.', 3288.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(7, 'Mollitia odit pariatur officia placeat.', 'Id aperiam accusantium eos. Unde adipisci consectetur officia laudantium aut ut. Rem impedit ea necessitatibus doloremque occaecati vel magni.', 9293.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(8, 'Sequi sequi molestias alias omnis aliquam minima quam.', 'Alias quas ut rerum qui quisquam et. Est sed quibusdam similique omnis. Aliquid et nobis cum sequi magni omnis.', 5243.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(9, 'Culpa voluptatem earum dolorem vitae perferendis ut tempora.', 'Et consequatur quos deserunt illo minus sunt molestiae rerum. Perferendis autem soluta est aut ut soluta repudiandae. Accusamus aut molestias molestiae. Hic sed mollitia at et.', 4713.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(10, 'Iure asperiores ipsa autem consequatur.', 'Similique voluptate quam blanditiis mollitia. Iusto doloribus non ratione et nemo et qui. Sint est officia est quidem.', 7774.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(11, 'Eligendi architecto pariatur id quis.', 'Aliquam occaecati fugit iste molestiae autem. Commodi qui non dolorum laboriosam perferendis sit. Laboriosam eum veritatis et.', 9146.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(12, 'Omnis molestiae cum non deserunt pariatur sit veniam.', 'Laborum iure id aspernatur nihil nobis. Incidunt odit quis quo consectetur et. Commodi a nihil non dolor quae qui quae. Ea rerum eveniet quod eos harum sint ratione.', 8202.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(13, 'Recusandae tenetur dolores qui sed tenetur fuga deleniti.', 'Repudiandae sunt aut eaque quas. Doloribus reiciendis quo aut consequatur. Aut quaerat consequuntur aliquid.', 9158.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(14, 'Numquam hic vitae est est aut.', 'Accusantium est eos quae et nihil dolor. Voluptate vitae eum veniam nam est et. Perferendis dolor similique labore et.', 3741.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(15, 'Nostrum modi sapiente ea voluptatem.', 'Dolore eum non voluptatem sequi non. Iusto dolorum veritatis a aperiam. Culpa nemo aut facilis quas.', 7380.00, 0, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(16, 'Ipsum deleniti et maiores excepturi eum nisi.', 'Voluptatem asperiores minima tempore odio similique quaerat. Eum animi maxime commodi et et sequi. Itaque a ut facilis commodi velit commodi inventore. Odio quod aut non nostrum nihil.', 322.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(17, 'Pariatur quod eum voluptatibus error incidunt mollitia necessitatibus.', 'Non mollitia expedita vitae. Autem dolore minus iusto modi illum assumenda. Consectetur animi sed nostrum nisi natus fuga repellendus quo.', 1709.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(18, 'Blanditiis voluptates iure corrupti quia itaque eos ea.', 'Nihil nobis sit earum nobis laborum possimus. At ullam enim necessitatibus sint. Voluptatem fuga fugit deserunt atque velit fugiat.', 3880.00, 1, '2021-09-01 06:55:05', '2021-09-01 06:55:05'),
(19, 'Totam rem temporibus sit praesentium et voluptatem animi ab.', 'Nulla magni voluptas deserunt officia. Amet tempora quasi cum ratione eaque praesentium. Recusandae officia accusamus error id.', 3777.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(20, 'Unde porro cumque veritatis expedita velit et consequatur.', 'Eum nihil eos delectus id atque. Repudiandae voluptatem eius velit. Vel beatae vel velit recusandae rem et voluptatem consequatur. Et est ut perferendis.', 9324.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(21, 'Error blanditiis excepturi optio et quod ab.', 'Similique maxime iure natus fuga corporis molestias ut. At incidunt similique ut error ipsam non. Ut possimus consectetur in odio est facere ut. Quis provident corrupti ducimus recusandae aut exercitationem corporis.', 8315.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(22, 'Nemo magnam ut assumenda voluptas unde.', 'Facilis nisi nobis nemo esse tempora. Quis quos sunt harum fugiat. At repudiandae pariatur quod.', 4647.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(23, 'Quis quae explicabo perferendis dolorum nam suscipit et eveniet.', 'Excepturi cum totam accusamus et. Sit numquam voluptatem voluptate animi. Ut rem possimus sit alias architecto ut odio. Aspernatur excepturi molestiae possimus sed dolorem quidem.', 410.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(24, 'Non sit qui consectetur voluptates quidem possimus vel accusamus.', 'Id dolores velit officiis totam voluptas laudantium et. Error cumque earum earum dolore et ut sed. Deleniti suscipit esse sapiente ullam. Vel qui quasi asperiores id.', 9340.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(25, 'Impedit nisi omnis velit et cupiditate sint.', 'Distinctio tempora aut est magnam eligendi molestiae error. Doloremque occaecati consequatur fuga error odio. Soluta veniam suscipit consequatur eum excepturi est.', 6209.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(26, 'Veritatis est voluptate qui ea nemo deleniti voluptate.', 'Vel autem maiores excepturi magnam. Omnis et corporis nemo. Vel cum neque et modi. Quos sequi vel modi doloremque labore accusamus consectetur modi. Qui veritatis et quos et quia similique.', 1638.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(27, 'Debitis et maiores veritatis.', 'Eum quidem ut eligendi omnis aut ullam ut. Rerum aut pariatur necessitatibus magni. Fugit sint omnis et dolorum fuga vel. Consequatur doloremque iste et quisquam reprehenderit numquam.', 9495.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(28, 'Occaecati quia deleniti consequatur sit sunt nihil.', 'Maxime dolor voluptatem reiciendis est. Est a qui enim quia. Aut voluptatem consequatur sit dolor. Qui cupiditate et consequatur eum qui ut assumenda.', 9049.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(29, 'Dolores inventore nobis officiis quia.', 'Et qui voluptatum vero tempore animi qui incidunt. Et laudantium ut quibusdam. Est unde odio aliquam corrupti ut aliquam. Esse voluptates cumque temporibus repudiandae.', 2513.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(30, 'Debitis consectetur dignissimos error dolorem.', 'Numquam mollitia delectus et commodi magni. Quis aspernatur suscipit ut minima magni. Doloribus quod et sint dolor nam ut quam id. Aliquid consequuntur sequi reiciendis fugit explicabo quo blanditiis illo. Et sed itaque quidem excepturi.', 9899.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(31, 'Odit voluptates maiores dolores iure assumenda ullam.', 'Molestiae quia qui deleniti autem recusandae veritatis sit. Sunt incidunt est hic nostrum ratione praesentium. Qui dignissimos porro reprehenderit nihil aut magnam qui.', 4151.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(32, 'Consectetur quisquam aliquam ipsam sit culpa.', 'Reiciendis ullam explicabo cum autem est iste sequi. Sit et aut voluptatem officiis. Provident sequi recusandae odio non. Consequatur quam ratione ipsam.', 5006.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(33, 'Aut eligendi perferendis qui molestiae in aliquid aut.', 'Occaecati quisquam vel delectus amet corporis mollitia doloribus. Labore et odit laudantium quae molestiae in pariatur. Dolore assumenda molestiae modi sed autem numquam. Autem porro et quos aut amet repudiandae quis aut. Voluptas facilis ex nisi accusantium velit doloribus error.', 2574.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(34, 'Amet magni molestiae sapiente adipisci est.', 'Debitis beatae voluptatibus voluptas esse eaque atque delectus consectetur. Aut culpa et sed adipisci.', 2424.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(35, 'Quia non iste iusto omnis laborum.', 'Sint ipsam minus recusandae nobis. Veritatis eligendi nostrum soluta ut cupiditate quasi. Sit sed eos reprehenderit recusandae perferendis consectetur deleniti.', 1694.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(36, 'Expedita et alias quia dolores est eos quia minus.', 'Sequi non sit maxime iure dolorem ipsam voluptatem consequuntur. Necessitatibus consequatur similique odio unde cum facilis. Quam nemo commodi quam cumque qui inventore omnis. Error voluptatum atque reiciendis est est. Sunt similique nostrum iste quo placeat voluptas ut fuga.', 858.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(37, 'Similique nisi placeat neque ut.', 'Natus ad blanditiis voluptatem aut possimus. Qui qui necessitatibus tempora. Asperiores id omnis minima sit.', 7127.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(38, 'Officia vero ut omnis molestiae.', 'Voluptates beatae voluptas ullam velit quo dolore aut. Odit iusto iusto ut nemo. Praesentium quia voluptatem vel repellendus quam. Nesciunt quas fugiat et eveniet.', 5695.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(39, 'Velit totam expedita non quas ea sapiente quo est.', 'Velit non iusto ea quaerat aliquid optio alias molestiae. Qui vero aliquid enim optio autem sint est. Et dolor libero repudiandae atque. Occaecati aliquid corrupti dolorem.', 7802.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(40, 'Nemo eum dolores ut facere eos.', 'Consequatur libero qui sed perferendis est sapiente velit. Sapiente sit in vitae aliquid quae aliquam fugiat. Voluptate ab voluptatibus unde est laboriosam. Sapiente at autem ipsum sed neque non.', 2216.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(41, 'Ut saepe voluptas error deserunt.', 'Omnis delectus atque ea. Ea eos veritatis quod quidem laborum. Consequatur nostrum rerum laboriosam facilis illum ut.', 3024.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(42, 'Vel ea molestiae alias voluptatem est reiciendis.', 'Cupiditate minus et voluptatibus et. Debitis velit dolore optio in. Corporis minima officiis occaecati optio.', 6492.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(43, 'Eum atque nesciunt culpa non.', 'Nulla eaque aut laborum in eum quam. Vel architecto adipisci sed harum suscipit. Et tempore quisquam eaque quo. Officia hic quaerat doloremque ut voluptate voluptatum.', 8919.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(44, 'Aut sed ducimus iusto omnis.', 'Totam minus assumenda perferendis praesentium. Harum sed qui molestiae corrupti iusto quis expedita. Quae ut ducimus corrupti praesentium. Aliquam dolores consectetur et dignissimos.', 6974.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(45, 'Distinctio et sunt harum ipsa.', 'Et ut cum deleniti architecto et saepe sequi. Possimus ullam doloremque distinctio quod. Quasi totam commodi non eos accusamus. Minima enim pariatur magni cumque asperiores nulla nihil voluptatibus.', 5960.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(46, 'Praesentium aspernatur natus inventore accusantium aut.', 'Officia neque deserunt non. Eos veniam numquam aut perferendis. In aliquid et omnis voluptatem in repudiandae.', 9017.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(47, 'Mollitia nesciunt voluptates unde qui eaque.', 'Magnam ut voluptas sunt cupiditate neque distinctio repudiandae. Ut tenetur dolor quaerat rerum accusantium voluptates sit. A aliquid ab ea repellat.', 508.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(48, 'Adipisci voluptatibus cum et quas ratione architecto sit.', 'Voluptatum ipsum quis eos quia vero consequatur. Fugit necessitatibus recusandae iste omnis dolorem optio. Quibusdam debitis non fugit amet eligendi nulla dicta.', 678.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(49, 'Ullam amet rerum cupiditate ut.', 'Dolor provident at est quis et aliquid voluptatibus. Quam incidunt tempore est laudantium facere qui. Dolore fugit numquam earum odit ut aliquid. Dolorum voluptas molestiae perferendis nostrum.', 7696.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(50, 'Ea voluptatem placeat sequi ipsa suscipit.', 'Et aut esse quis temporibus. Error sunt consequuntur consequatur expedita dolores. Ut nam et est est quis.', 7157.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(51, 'Iusto alias non totam consequatur.', 'Nulla error repellendus accusamus nisi et consequuntur. Ut nesciunt minus beatae facilis culpa provident eaque. A aut facilis eligendi tenetur repudiandae similique laborum.', 5718.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(52, 'Est est sed nostrum explicabo.', 'Perferendis amet ipsa sed. Eligendi non qui autem eligendi aut itaque. Vel provident occaecati laudantium architecto nihil eum dolor est. Nemo in eligendi aut eligendi blanditiis fuga harum.', 7467.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(53, 'Ut dolorem iste ad illum pariatur reprehenderit rerum.', 'Eos quia corrupti veniam ut tenetur. Mollitia fuga odit quam. Voluptatibus ut quia soluta odit eaque. Unde odio aut voluptatem quod. Ut quos maxime ex illum.', 4307.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(54, 'Esse consequuntur dolor amet rerum ut pariatur.', 'Nemo possimus quibusdam blanditiis corrupti error ut. Maxime sit magni repellat consectetur ex. Culpa odio et voluptatibus provident rerum. Reprehenderit quia est tempora neque.', 8090.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(55, 'Aliquam neque repellendus eum veritatis ut.', 'Voluptatem voluptate laborum magni. Eaque earum aut esse. Aut eligendi blanditiis architecto sit.', 7701.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(56, 'Velit voluptas et qui.', 'Sed ipsam nisi quia quo quibusdam qui asperiores. Ad iure ea rem vel. Sed laboriosam consectetur et ipsum necessitatibus ex. Et quo iusto in voluptas.', 6697.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(57, 'Facere et quis accusamus velit.', 'Non illum tempora fugit amet suscipit. Reiciendis necessitatibus aut quia dolorum odio alias. Repudiandae sunt explicabo dignissimos provident et minus. Consequatur voluptatem laborum provident quisquam fugiat omnis.', 2024.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(58, 'Nulla inventore voluptate nam reprehenderit ea neque ipsam.', 'Adipisci nemo similique vero aperiam. Quia voluptate rerum ut voluptatem et sapiente sit id. Dolore est ipsum dolores dolorem dolores repellat eos.', 1225.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(59, 'Vitae quas dolores tempora magni enim fuga.', 'Itaque facere odio occaecati eligendi asperiores. Dolor ab delectus ipsa cupiditate. Molestiae enim laboriosam est voluptates saepe omnis. Corrupti consequatur quaerat sed ut sit.', 801.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(60, 'Aut odio incidunt optio tenetur sit blanditiis vel.', 'Ratione temporibus nobis itaque minus quas sit. Soluta quia quasi fugit asperiores enim veritatis quis.', 7752.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(61, 'Autem eos qui quisquam laboriosam dolores.', 'Sequi vitae expedita odio autem autem nihil alias. Eveniet eum nulla et qui ducimus quaerat. Et est sed officiis facere.', 3079.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(62, 'Porro et omnis qui.', 'Ad voluptate assumenda minima accusamus labore veniam cupiditate natus. Laudantium delectus tempora iure temporibus qui molestias. Sapiente earum quia eveniet earum quae facere. Ut nobis tempora rem modi.', 6399.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(63, 'Esse perferendis repudiandae ex et velit id nam.', 'Vitae in praesentium voluptatum libero sint eum. Nostrum odio omnis nemo fuga. Accusantium aut harum id quis.', 5991.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(64, 'Quia voluptatem consequatur pariatur sapiente.', 'Dolorem a vitae et sed dolorem. Eius porro et omnis est. Omnis nam ea praesentium ullam magnam impedit magni odit.', 8830.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(65, 'Ut reprehenderit a vel maxime dicta.', 'Numquam et enim fugiat similique aut. Aliquid illum minus ut eveniet ut. Sequi et quis iure.', 8295.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(66, 'Et aut distinctio consectetur sed maxime.', 'Rem dolorum labore non illo expedita deleniti. Sint dolores porro optio sit sunt qui. Odit eaque minima perspiciatis doloremque. Aperiam enim iusto aperiam qui aut magnam aut autem.', 1458.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(67, 'Sed esse tempora illo tempora qui.', 'Consequatur voluptatem commodi expedita ea earum. Reiciendis perspiciatis ut est ad.', 9013.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(68, 'Inventore sunt aliquid numquam delectus repellat veritatis.', 'Nostrum maxime consequatur in maiores aut. Ea tempore vitae eos nihil minima. Aut voluptate voluptatibus voluptatum delectus cupiditate eos quo sint.', 8529.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(69, 'Quo consectetur distinctio in nesciunt voluptatem placeat accusantium.', 'Qui quia minima possimus sed temporibus voluptatem consequuntur sapiente. Animi quos quo ipsam quo iste asperiores non. Veritatis nobis consequatur deserunt magni nostrum iure. Harum temporibus dolore eveniet incidunt ipsum vel ut. Corporis voluptatem ex esse sint sapiente.', 2670.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(70, 'Suscipit odio incidunt non dolores porro magni dolores.', 'Optio sed quibusdam saepe dolores. Consequatur rerum cumque omnis harum unde totam qui dolor. Earum molestiae optio doloremque quo. Velit delectus a placeat modi dolor est. Natus ut sint quia eligendi ducimus deserunt quisquam.', 9450.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(71, 'Iste non nihil veritatis cupiditate ad quisquam et.', 'Minus veniam mollitia cum laudantium dolorem amet. Ea alias repudiandae iusto sint saepe possimus. Earum quidem beatae id earum facilis cum.', 4143.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(72, 'Magni provident a sit est.', 'Atque qui iusto sapiente laudantium et ad eligendi. Soluta dicta ducimus dolorum in a. Inventore consectetur nostrum voluptatem omnis vero ut commodi eius.', 9605.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(73, 'Non deserunt et id consequatur voluptate.', 'Dolorum et minima aliquam tempora ad quia natus. Corporis illo odit tempora optio aut repellendus sint. Sed consequuntur sed deleniti assumenda exercitationem. Molestiae consequuntur aperiam aliquid velit enim corrupti qui quod.', 5503.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(74, 'Dicta accusamus deserunt id et sit aperiam officia.', 'Pariatur magni nam magni tempore aut. Ea provident exercitationem tempore quia voluptatibus ut. Nihil aut minus ut delectus velit quidem consequatur voluptatem.', 4612.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(75, 'Quis suscipit fugiat fuga deserunt molestiae et corrupti.', 'Unde voluptas occaecati labore et et. A nostrum recusandae et dolor aliquam sunt. Qui harum odit repellendus ut maiores dolorem.', 9604.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(76, 'Dolor dolorem accusamus impedit.', 'Perspiciatis consequuntur sunt nobis quia iusto in. Velit eaque voluptas nulla dolorem quas voluptatem. Iste et voluptatem cupiditate est veniam doloremque quo.', 2951.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(77, 'Facere repellendus qui tenetur.', 'Nihil repellat voluptatem inventore cum commodi. Tempore ipsa iste voluptatem mollitia. Ullam sequi molestiae ab vel ut dolorem unde.', 4625.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(78, 'Enim est ullam ipsam repellat qui minima architecto.', 'Sequi distinctio numquam recusandae qui debitis. Et sint pariatur voluptatem officiis. Dolorem totam porro est autem repellendus sunt.', 1956.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(79, 'Fuga id et quos repellendus.', 'Labore qui est id. Consequatur recusandae consequatur quia totam. Harum labore dolor harum occaecati. Voluptas et sit voluptatem laborum modi quos quae.', 1974.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(80, 'Illum nam deserunt delectus at labore.', 'Ut explicabo eos voluptas aut minus occaecati veritatis ut. Ipsam et doloribus facilis sed est. Quis veritatis tenetur tempore sint voluptatum et.', 3698.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(81, 'Accusantium quis dolores dignissimos natus ea assumenda aut.', 'Eum ut amet fugiat qui vero. Eum ad a sunt beatae odit et. Repellat perferendis est et eum facilis.', 2969.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(82, 'Corrupti atque et et totam quia.', 'Ut vel dolorem quaerat ut. Qui modi enim impedit consequatur maxime saepe a. Non corrupti cupiditate quidem accusamus. Soluta eius rerum aliquid cum ipsum nam. Id sed veniam quis commodi quibusdam culpa nihil.', 8284.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(83, 'Culpa corrupti ut fuga repellendus.', 'Ea non tempore quia ut quia placeat tenetur. Voluptatem dolorem iure aut inventore facere rem. Ipsa et autem earum rerum dicta. Non occaecati rem neque.', 6860.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(84, 'Velit quo ut incidunt ipsam qui dolorem neque iusto.', 'Laborum sunt eligendi modi dolor. Incidunt necessitatibus eligendi omnis ipsam consectetur dolore dolor. Impedit et aut qui quo maiores nihil.', 6328.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(85, 'Minima cumque alias ea eum non vero.', 'Possimus quia aut eos non ea autem. Architecto voluptas maxime quas suscipit. Quod architecto iusto tempora harum ut veritatis aut. Delectus quae optio sapiente beatae inventore placeat.', 7552.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(86, 'Qui pariatur facere accusamus qui enim saepe.', 'Provident et quaerat laborum. Aperiam facere quaerat et veniam delectus pariatur ratione nemo. Deleniti expedita debitis temporibus perspiciatis nam consequatur sed. Voluptatem molestias nihil assumenda qui autem.', 4291.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(87, 'Aut ullam repellendus eos sit id.', 'Rerum sunt alias voluptatibus. Tenetur laboriosam asperiores consequatur repudiandae aperiam similique. Ex enim quia dolorum cupiditate molestiae quae earum. Esse qui praesentium consequatur tempora error.', 1329.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(88, 'Tenetur vitae sit fuga quibusdam saepe.', 'Mollitia et alias amet voluptate distinctio. Dolor ea eos rerum ipsam. Tempora sint impedit quia blanditiis et corrupti.', 2998.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(89, 'Qui quidem quae in.', 'Sint atque rerum quia laudantium praesentium explicabo. Est animi repellat ad occaecati est.', 4919.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(90, 'Voluptatem delectus inventore consequatur eos.', 'Et et consequatur qui autem aut temporibus. Et placeat ut ea molestias. At aut provident iure iusto et. A iusto id velit minus cupiditate iste. Maxime incidunt voluptatem et illum veniam voluptas tenetur.', 2984.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(91, 'Minus eos recusandae aspernatur dolorem ratione suscipit fuga.', 'Quas error dolore suscipit cum voluptatem. Temporibus sit asperiores sed eaque minima et dolorem. Ut sit aut est cum quod.', 9205.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(92, 'Rerum architecto commodi qui rerum.', 'Praesentium adipisci nam deleniti rerum enim rerum. Aut mollitia vero consequatur adipisci esse deserunt exercitationem ab. Sit debitis ex cupiditate sed modi. Quia rem ab corporis autem possimus qui esse.', 7036.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(93, 'Ducimus aperiam qui laboriosam fugit.', 'Blanditiis rem laboriosam impedit. Ipsa dolore quisquam quam est hic repellat. Vero incidunt voluptas fugiat voluptatum iure. Eum voluptates porro modi sed id voluptas ratione. Harum delectus architecto quasi fugiat voluptatibus consequatur.', 2405.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(94, 'Perferendis est corrupti fugit perferendis.', 'Provident deleniti ex ratione sint. Explicabo magni qui perferendis non excepturi sint. Temporibus rerum ea rem. Nesciunt ut quae qui magnam rerum.', 2794.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(95, 'Aut perspiciatis vitae at est sint ducimus.', 'Voluptatem et optio qui maiores ut. Provident et ipsam debitis dolores voluptatem omnis. Voluptatum illo molestiae natus illo aut magnam ea omnis. Fuga quaerat qui ipsum vero.', 772.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(96, 'Fugiat quos reiciendis saepe ut neque quos odit.', 'Quam architecto nobis accusantium quisquam sed fugit harum. Ratione dignissimos repudiandae ut dolore autem eius. Sunt architecto repellat molestiae necessitatibus praesentium. Eveniet praesentium eligendi ea voluptatem et provident.', 1108.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(97, 'Soluta saepe assumenda voluptatibus et repellendus necessitatibus error.', 'Iste ipsum facere sit eligendi et iusto aut. Corporis reiciendis ipsam eum et. A ullam voluptatem aperiam tenetur dolor omnis sapiente. Voluptatem quia non voluptatem totam. Reprehenderit velit itaque est non aut est.', 7066.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(98, 'Qui dolor omnis suscipit.', 'Voluptas ut doloribus deleniti et consequuntur facilis est. Inventore eveniet natus vel odit numquam labore. Veritatis quos autem dolorum sed accusamus mollitia et. Cum sit corporis aut et quo sunt id.', 4644.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(99, 'Dolorem rerum in et corrupti optio fugit.', 'Sed reiciendis vel dolorem ut beatae aut. Dolores quo impedit veniam quo quae quia amet et. Quidem sunt quia atque ipsam consequatur aut suscipit consequuntur.', 7694.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(100, 'At eum excepturi fuga velit et.', 'Quo esse voluptatem quisquam ducimus ipsum. Pariatur et dolorem non. Optio fuga ducimus est maxime praesentium vel excepturi. Delectus saepe id reprehenderit ratione. Assumenda amet vitae quo autem id tempora.', 9000.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(101, 'Sint nisi quas voluptatem quisquam aspernatur dolore excepturi.', 'Tempore iste quod voluptatem iusto similique. Molestiae laborum eveniet rerum consequuntur qui. Suscipit tempore eaque nihil et voluptatem sunt. Ut officiis maiores unde excepturi autem laborum.', 707.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(102, 'Quia magnam maxime temporibus dolorem excepturi eos eos non.', 'Sed est rem reiciendis asperiores velit voluptate ut quia. Corporis dolorum quod eum aut delectus laborum. Quo asperiores quaerat sed praesentium eum. Fugit id sequi harum cum laborum cumque nulla iure.', 3349.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(103, 'Ut ea corporis quod aut.', 'Vel omnis magni eligendi illum earum ipsa voluptatem quis. Veritatis quas ad magni iste est veniam. Aspernatur velit quidem dignissimos in sit fuga.', 9137.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(104, 'Ex et atque ut impedit sint consequuntur.', 'Non assumenda fugit quis nulla aperiam architecto. Et ratione labore eaque. Aliquid maiores maiores quia voluptatibus ducimus sed. Exercitationem mollitia expedita dolorem esse. Aspernatur optio aut aliquam quia facere rerum.', 3829.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(105, 'Voluptatum vel molestiae quo.', 'Autem sapiente tempore et at adipisci nobis. Tempore blanditiis qui cupiditate quis atque. Similique eum accusantium quaerat non voluptatem aut magni.', 5673.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(106, 'A eaque aut sed eaque vel sequi dolores.', 'Dolore quasi dolorem cupiditate autem et quis delectus. Non est ipsa voluptas est. Ducimus minus dolores voluptates occaecati sit similique reprehenderit.', 5803.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(107, 'Dolore ut modi consequuntur eos ipsam eos sequi.', 'Sed molestiae atque rerum eligendi explicabo ut. Impedit eligendi inventore totam soluta sunt maxime et voluptates. Sint ea optio commodi ut.', 7296.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(108, 'Dolor laborum dolorum voluptas laudantium ducimus voluptatem sit.', 'Vel qui labore fugiat aut beatae velit et. Sed porro minima debitis ratione earum corrupti. Eaque iste dolorem architecto est illum sint aliquam. Rerum praesentium laboriosam illo quo.', 315.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(109, 'Et nulla iste molestiae qui.', 'Autem atque aperiam sapiente omnis occaecati voluptatum in. Nisi saepe libero quo consequatur vitae. Exercitationem dolorem tenetur libero aut adipisci. Molestias dolorum et aliquid sit et maiores perspiciatis voluptas.', 7719.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(110, 'Porro omnis in doloribus tempore dicta minus.', 'Inventore dolores neque magni et. Enim sunt consequatur incidunt sit perspiciatis officia. Voluptas ab nesciunt ut dolor.', 8561.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(111, 'Aut ducimus veritatis quos accusantium vitae voluptatum porro.', 'Harum soluta error atque. Eos molestias nisi fugiat exercitationem voluptas sint. Ut rerum et sit aut.', 7983.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(112, 'Corrupti veritatis et aut consequatur.', 'Rerum qui minima magni minima. Distinctio cupiditate explicabo sit nam rerum et.', 3937.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(113, 'Voluptate facere earum est rerum quia est.', 'Odio et animi non est natus itaque vitae repellat. Sit pariatur adipisci veniam consectetur neque illum eveniet. Praesentium dolorum excepturi veniam fuga et aut consequatur.', 4015.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(114, 'Rem et recusandae dolore quasi.', 'Recusandae cupiditate voluptatem hic voluptatem eum iste eius. Quos eius repellendus sit dignissimos autem. Officiis qui delectus qui. Asperiores non porro autem eum.', 4065.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(115, 'Molestias voluptas eaque repudiandae quam.', 'Sit recusandae facilis aut minus dolor eligendi deleniti. Quo similique blanditiis harum et nesciunt tempora corporis veritatis. Ipsum qui non qui occaecati. Fugiat odit dolor molestiae delectus perferendis. Aut sint et ea facere aut.', 3746.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(116, 'Quia voluptatem asperiores beatae esse rem aut.', 'Saepe quibusdam praesentium perspiciatis voluptas ut. Quia vero iste eos qui harum in. Deleniti aut ut veritatis optio nesciunt. Cum quod soluta sit sapiente.', 6271.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(117, 'Non delectus et facilis adipisci.', 'Dicta voluptas vero et consequuntur consequatur. Commodi magnam ipsum eaque cumque molestiae occaecati dolores amet. Deleniti voluptas necessitatibus et voluptas nobis consequatur quia. Libero impedit numquam nisi facilis totam ut.', 6121.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(118, 'Repudiandae possimus tenetur delectus.', 'Non autem aut perferendis qui eos temporibus. Omnis et est et eos id natus delectus. Repudiandae earum earum est voluptatum dignissimos.', 3158.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(119, 'Veniam at recusandae et ex libero.', 'Quis non ut earum. Et quo doloremque voluptatem voluptatibus a. Ipsum possimus reiciendis non et qui distinctio. Labore pariatur sint recusandae facilis ut soluta quisquam.', 5151.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(120, 'Quod nesciunt eos nam.', 'Laudantium minima fuga sit rerum et nam earum. Aut nihil omnis repellat laboriosam sit. In ut pariatur doloremque sed pariatur numquam quia. Aut et sint dolor perspiciatis qui tenetur.', 8507.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(121, 'Soluta eligendi labore fugiat vel.', 'Cum distinctio qui asperiores consequuntur est voluptate dolor. Accusamus non corporis cupiditate. Voluptate itaque est corrupti non expedita voluptatibus occaecati ea. Esse mollitia molestias sit error voluptate deserunt perferendis.', 6056.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(122, 'Illo adipisci consequatur quos eos porro fugiat suscipit ea.', 'Nemo distinctio facere qui sit veritatis dolore et. Accusantium consequuntur molestiae voluptas et. Qui odio ut quo voluptatibus.', 7523.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(123, 'Cum quasi incidunt iusto.', 'Est sit debitis consequatur similique quas est eos. Libero odio iste nihil consequuntur et consequatur architecto. Sed hic quos nulla officiis nisi delectus.', 6581.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(124, 'Exercitationem et et enim quod.', 'Reprehenderit non enim itaque. Hic veniam unde at. Minus hic magni sunt rerum rerum.', 9234.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(125, 'Nam soluta sed fugiat consequatur illum.', 'Dolorem doloribus nihil excepturi aut mollitia ratione amet. Velit neque enim fugit sit dolore distinctio. Repellendus est sed similique delectus dolorum illum provident.', 3318.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(126, 'Aut cupiditate id facilis enim ut dignissimos aut cupiditate.', 'Vitae rerum deleniti nesciunt. Quis temporibus ipsa est. Sunt numquam blanditiis omnis eius ad quam. Eius aut mollitia excepturi molestiae cupiditate qui quod dolorum.', 6646.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(127, 'Eaque eum delectus autem assumenda.', 'Vel enim aut dolores officiis. Labore maxime modi ea amet mollitia maxime. Architecto necessitatibus eum optio ea.', 5969.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(128, 'Et commodi et facere omnis velit consectetur.', 'Deserunt similique officiis et dolore et voluptas. Excepturi libero placeat fuga fugiat eaque. Blanditiis dolorem placeat perspiciatis numquam accusantium ad. Vitae quia autem repellat sed saepe earum.', 5453.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(129, 'Debitis sed fugit non sequi doloribus sit.', 'Quis iste autem quas recusandae et quibusdam omnis. Velit nobis dolor quia. Eligendi dolor et molestiae sunt. Fugiat sit quisquam impedit et et.', 8791.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(130, 'Esse et recusandae optio assumenda ipsum rerum.', 'Dolore iste sint consequuntur repellendus non repellat suscipit. Et illum cupiditate omnis consectetur tempore. Sit harum in non enim perferendis magnam. Sequi praesentium sunt laboriosam.', 8059.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(131, 'At asperiores atque in voluptate.', 'Vel ducimus ut delectus maiores. Ex porro ex at et alias voluptate. Quidem quos assumenda odit voluptatibus placeat corrupti modi.', 1247.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(132, 'Excepturi repellat recusandae ut.', 'Qui nam repudiandae iusto odit consequatur quos velit omnis. Et possimus a quisquam. Deleniti ut rerum necessitatibus repudiandae. Praesentium fuga delectus quia dolore accusantium voluptas.', 156.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(133, 'Sit nemo quaerat est animi dolorem.', 'Voluptates dolores natus magni aut ratione velit et. Consequatur vitae illum quia quos magni voluptates.', 6600.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(134, 'Hic omnis et vel et.', 'Hic quis natus aliquid quas maxime rerum eius cupiditate. Et rerum a quia iusto esse. Quaerat error eum qui et.', 6438.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(135, 'Occaecati labore fuga commodi sapiente.', 'Et quod et earum asperiores qui et fugiat. Earum cum et nisi ullam unde doloremque. Quo nihil ut omnis exercitationem cum. Est fuga ea ut molestias et quia unde totam.', 2745.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(136, 'Dolor quis autem mollitia id occaecati.', 'Itaque soluta quia tempore sed incidunt quia. Ipsa qui enim ut blanditiis. Quod dolores voluptatibus veritatis aspernatur. Illum aut quis id corrupti iste aperiam.', 4841.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(137, 'Minus porro eveniet autem consequatur quos exercitationem quo voluptatem.', 'Quis ipsum animi delectus est quos fugiat. Eos qui accusamus eum ut. Beatae corporis omnis sit quibusdam.', 3717.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(138, 'Occaecati aut ut sint nihil.', 'Nihil cumque animi dolores explicabo. Accusamus soluta est quam itaque expedita aut ducimus. Dolorem in dolores rerum quas.', 7872.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(139, 'Vero eveniet consequatur occaecati deserunt.', 'Qui aliquid eligendi pariatur voluptatem non sit non voluptate. Laudantium ipsa cum voluptate dolorem consectetur magni. Alias quis velit consequatur id ratione dicta voluptatem delectus.', 6260.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(140, 'Atque fugiat architecto nesciunt quo corrupti.', 'Est deleniti dolorum ut nesciunt. Ut esse eum odio perspiciatis doloribus eum laudantium. Sit est et ipsa aut. Et in dolore consequatur dolor hic est. Quibusdam molestiae dolorem deleniti facilis earum et.', 5551.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(141, 'Sunt velit odit architecto nihil.', 'Quasi dolores vero voluptatem alias assumenda repudiandae. Quo sint quaerat itaque non. Consequatur fugiat quae rerum.', 7836.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(142, 'Autem aut laborum a fuga cupiditate et.', 'Omnis illo et ab neque dolor corrupti commodi. Sint possimus architecto sed quam voluptatem et odit quasi. Consequuntur voluptates dolorem earum sit odio excepturi. Nihil officiis maxime rerum repudiandae amet iste.', 7803.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(143, 'Expedita similique impedit quas suscipit veniam.', 'Accusantium distinctio libero occaecati nostrum. Modi aut eos rerum tempora ipsa quam sequi. Dicta praesentium natus officiis aliquam laborum ea vel. Quaerat adipisci voluptatem sint doloremque omnis.', 4012.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(144, 'Non autem iusto qui nulla sed.', 'Dolorum provident eveniet officiis. Tempora aut dolore accusamus totam in nihil. Possimus sapiente quia dolorem sapiente est.', 5677.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(145, 'Exercitationem dignissimos accusantium aut est illum ullam aut.', 'Illum quos nihil impedit est. Dolores eligendi atque eum est quam sint tempora. Cum magni porro a soluta. Delectus facilis veritatis suscipit aut doloribus tempora.', 8634.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(146, 'Non voluptatem nam veniam.', 'Delectus dolore accusamus omnis doloremque recusandae et animi. Neque qui culpa laborum. Aut ratione quia voluptas nisi repellat animi reiciendis. Rerum rerum cumque optio enim provident ab.', 4319.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(147, 'Laboriosam nam culpa et architecto ad debitis aspernatur.', 'Iusto nostrum ratione velit repellat dolores consequatur delectus. Delectus consequatur omnis temporibus laboriosam accusamus id. Eum itaque illum ea totam libero quo. Nostrum doloremque voluptatem officia. Quo non dolorem voluptate.', 3537.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(148, 'Illo vel facere similique hic.', 'Ratione fugiat illo dicta qui. Doloremque dolore maxime magni nesciunt. Odio et blanditiis qui voluptatum nostrum ut facere tempora.', 5990.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(149, 'Odio rerum praesentium quia unde laboriosam.', 'Mollitia tempore esse itaque commodi deserunt distinctio unde. Sed quaerat reprehenderit et deserunt enim rem. Iste dolor dolores pariatur. Velit adipisci id provident fugiat id qui et.', 526.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(150, 'Sed mollitia accusantium ab ut id doloremque hic distinctio.', 'Mollitia magni illo facilis error culpa. Fugiat doloremque sunt facere quo.', 2351.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(151, 'Voluptas voluptas sed ut et.', 'Facere et eos quia culpa rerum error. Quis sint fugiat et recusandae quasi neque. Omnis est reiciendis totam qui quae. Optio sunt ipsa consequatur est accusantium.', 1072.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(152, 'Non aut tempora rerum praesentium.', 'Quibusdam corrupti at quia repellat est repellat. Debitis totam labore ducimus voluptatum repellat ipsam. Et neque ea ducimus perspiciatis qui alias.', 1302.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(153, 'Corrupti aut iste alias dolorem ut est officiis quam.', 'In assumenda et culpa commodi porro necessitatibus non. Molestias dolores quo tenetur tempora perferendis sed. Suscipit voluptas ut laboriosam ut tempora velit. Itaque ipsam rem ducimus deserunt veritatis porro et odit. Minus non similique vero ut.', 1521.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(154, 'Ab aut ea ut suscipit odio assumenda ipsam.', 'Vitae magnam explicabo culpa nihil omnis quo consequuntur optio. Et veniam neque sed. Et quia voluptas ut eius delectus. Quod omnis nobis pariatur possimus.', 9003.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(155, 'Iusto similique et dolor doloremque sit et fugit.', 'Assumenda quidem voluptatem a omnis voluptatum delectus odit. Et harum dignissimos quam temporibus. Quia veniam est earum.', 2007.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(156, 'Rerum totam omnis aut ipsum omnis eligendi ex.', 'Molestias doloremque animi voluptatum. Repudiandae exercitationem quos qui quae. Tempora quia dolorem accusamus autem nemo. Sit in natus illo id. A commodi dolor qui magnam odio.', 3671.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(157, 'Quo magni commodi dolores quia nam.', 'Vel molestiae ut minus harum praesentium. Quisquam sed in accusantium illo. Est dolorum iure ea ut fuga quas dolore.', 2554.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(158, 'Sapiente perferendis impedit magnam.', 'Id doloribus est harum distinctio. Non cumque odit doloremque nesciunt hic. Saepe sunt fugit quia.', 3313.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(159, 'Aut voluptatem beatae recusandae dolore facilis sed.', 'Dolor quia sequi accusantium qui ad nihil omnis assumenda. Rerum exercitationem in dolorum quia pariatur et. Nisi corrupti dolores ea eos ut voluptatem et. Molestias ut aut placeat doloribus quia quaerat vel.', 4482.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(160, 'Quo enim quas deserunt ut sapiente.', 'Rerum consequatur architecto omnis veniam molestiae ducimus. Occaecati veniam sit ipsum doloribus non quae quia totam. Aut unde non ratione eos cumque facere quia non. Quia nihil doloribus ut distinctio est occaecati minima.', 7527.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(161, 'Dicta optio sunt sequi libero.', 'Porro assumenda odio omnis nemo illum. Quia natus nobis quibusdam ipsum neque quae. Animi et tenetur iste sunt consequatur fugit numquam.', 153.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(162, 'Hic qui illo suscipit exercitationem illum.', 'Et sint animi distinctio minima aut dolorem. Doloribus suscipit beatae possimus aperiam quam. Eaque ducimus ut ex ea placeat.', 7801.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(163, 'Ut ut eaque qui fugit eaque rerum eos deserunt.', 'Eveniet ea veritatis dicta quasi porro sit. Assumenda quibusdam cupiditate quis et reprehenderit eum. Id voluptatem ut quo consectetur aut blanditiis.', 1746.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(164, 'Id dicta fugit est odit veniam.', 'Qui aut molestiae reiciendis et provident rerum dolore. Pariatur in repellat ducimus tenetur ullam quae laborum. Est culpa asperiores est error itaque sit omnis. Aliquid debitis quo at est ex est. In minima veniam consequatur ad hic et sunt dolore.', 7333.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(165, 'Et quia quasi inventore facere.', 'Et quia dolor minima et. Hic maxime voluptatem eveniet a repellendus ducimus nisi. Sed rerum deleniti nihil placeat sed. Placeat eum harum aut sint quos corrupti blanditiis enim.', 1946.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(166, 'Molestias voluptatibus repudiandae illo molestiae sit reiciendis.', 'Voluptatem qui adipisci et culpa. Debitis placeat numquam in sapiente dolorum odio. Aperiam quod est dolorem omnis.', 7707.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(167, 'Soluta sed cupiditate rerum occaecati in dolorum aut voluptates.', 'Ullam occaecati enim aut labore est officia temporibus explicabo. Beatae enim qui accusantium sunt. Suscipit maxime distinctio rerum pariatur. Non vitae eos ad officia.', 7116.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(168, 'Praesentium porro autem autem deleniti voluptatibus sed.', 'In voluptas totam praesentium aut laborum ut ut. Consequatur et aut similique aspernatur est quia. Quia tempore inventore facilis nulla repellendus. Perferendis nemo molestiae aliquid enim ab quo.', 809.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(169, 'Sed aspernatur laborum voluptas totam.', 'Nostrum qui et est esse. Est et optio sit harum expedita iste. Autem molestiae mollitia voluptas et debitis sint eos. Est quis dolorem cumque ducimus explicabo.', 8864.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(170, 'Impedit qui corrupti harum ullam.', 'Doloribus sapiente sint officiis et. Aut incidunt maiores voluptatum maiores quisquam et aperiam. Fugiat adipisci recusandae labore expedita et omnis reprehenderit. Et totam non magni occaecati quasi inventore atque.', 3365.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(171, 'Ipsam et modi voluptatem iure vero esse.', 'Quia soluta quibusdam ea. Eos nam corrupti beatae sed excepturi.', 1368.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(172, 'Perferendis repellat maiores quia enim ad nam.', 'Sint voluptas eveniet impedit accusamus aut id. Non saepe voluptate inventore aut sed autem facilis maxime. Nobis voluptatem sit nihil qui odit repellat laborum. Rerum id assumenda expedita cum minima enim impedit.', 6528.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(173, 'In eligendi aperiam est voluptas ducimus eaque tenetur.', 'Molestias illo at fuga qui ullam molestiae. Non fugit ratione nihil. At nesciunt occaecati totam qui libero.', 2493.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(174, 'Ducimus aut totam dolores et nostrum eos.', 'Sed voluptas molestiae rem eius ea rerum aut dicta. Temporibus ipsa et officia veniam. Voluptatibus corporis animi aut. Repellendus aut doloremque sit quos necessitatibus sunt molestias.', 6686.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(175, 'Libero iste et quisquam nihil voluptatem.', 'Animi id ut facere et. Voluptates dolorem earum rerum nesciunt. Distinctio esse ex eligendi consequatur. Aut est non non sed.', 6633.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(176, 'Aut vel excepturi molestias amet sequi omnis enim.', 'Ea voluptas minima suscipit ipsum. Doloribus minima nostrum qui fugit laboriosam. Ex numquam facere at quod expedita possimus sunt.', 3176.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(177, 'Labore eos ipsam consequatur incidunt.', 'Ipsum eveniet officia voluptates esse. Aut corrupti voluptatibus voluptas. Quidem nobis nostrum qui perspiciatis.', 4287.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(178, 'Dolore recusandae et asperiores libero ea rerum.', 'Tempora quam quis dolore et dolor quam et. Necessitatibus dignissimos quia commodi non tempore explicabo aut. Nobis dolore ea sint aliquid corporis nobis sunt. Placeat sunt ut et quibusdam non rem veniam.', 1937.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(179, 'Qui sit tempore aut.', 'Veritatis voluptatem occaecati cum hic inventore dignissimos. Provident omnis iusto dolore qui quas rem. Corporis eos quia aut a voluptatem.', 7111.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(180, 'Nesciunt quis velit culpa occaecati suscipit modi.', 'Mollitia excepturi ea sed dolorem consequatur odit dolor. Tenetur veritatis voluptatibus est. Aliquid consequatur aut voluptatem earum laboriosam magnam.', 6374.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(181, 'Voluptates et vitae optio sint non beatae.', 'Aperiam veniam eum ut consequatur. Temporibus quas nihil consequatur debitis aliquid laudantium expedita velit.', 9306.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(182, 'Omnis debitis dolores autem et quos sit.', 'Unde et ab facilis culpa. Ipsa facere quam ipsum labore quae quisquam. Quia harum non corporis quo molestiae. Atque pariatur impedit explicabo est quidem reprehenderit est.', 9448.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06');
INSERT INTO `items` (`id`, `name`, `description`, `price`, `is_active`, `created_at`, `updated_at`) VALUES
(183, 'Odit est qui sapiente et.', 'Sit itaque odio voluptatem voluptatem veritatis. Officiis aut dolores nam et sapiente possimus. Velit cupiditate nulla molestiae repudiandae doloribus ratione recusandae ut. Enim sed porro fugit quasi libero ut. Soluta ducimus odio alias eum rem animi quos.', 2023.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(184, 'Reiciendis quia sunt sed id.', 'Doloribus suscipit ut fugit reprehenderit in repellat eum. Odio autem aliquam omnis autem ea natus. Commodi libero ullam consequatur sint quos. Impedit voluptas beatae saepe placeat.', 3523.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(185, 'Recusandae modi ut est beatae.', 'Itaque ab est modi. Natus tempore voluptas corporis omnis reiciendis. Deleniti voluptatem libero laboriosam exercitationem.', 5996.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(186, 'Qui consectetur facilis praesentium dolor.', 'Nihil voluptatibus excepturi quod eum sit aut voluptas et. Amet et est sit unde aut.', 8531.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(187, 'Suscipit delectus aperiam nisi quasi quo.', 'Natus delectus illo dolorum quia ut nihil. Excepturi et dolores eos dolores ea aut odit. Laudantium et aliquam ipsa perferendis quo.', 1767.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(188, 'Culpa qui magnam sed cum temporibus.', 'Quia rerum dolor non fuga. Debitis expedita ut dolorem sint et sint sed. Pariatur est dicta quia provident enim id. Voluptatum vel quisquam consequatur unde et. At impedit in magnam.', 1771.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(189, 'Accusantium eum suscipit nihil et aut veritatis recusandae.', 'Labore accusamus consequatur est quia dicta eius perspiciatis. Illum sit vel qui soluta cum quia quisquam.', 891.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(190, 'Ea et harum reiciendis maxime ab qui occaecati.', 'Sit pariatur minima qui occaecati perferendis quibusdam. Ut cum voluptatem culpa excepturi quidem. Architecto eum reprehenderit voluptas ut rerum. Voluptatem eveniet odio quisquam perferendis et.', 7734.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(191, 'Nesciunt possimus qui dolores sed velit in sint.', 'Dolores fuga tempora voluptatem velit corporis quo blanditiis. Veniam esse ut omnis harum voluptatem explicabo.', 9954.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(192, 'Ut magni temporibus consequatur quia.', 'Sint reiciendis nemo deserunt at adipisci ipsa. Tempore maxime odio sapiente est molestiae.', 5353.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(193, 'Recusandae pariatur molestias neque ratione molestiae totam.', 'Corporis aspernatur consectetur distinctio labore nemo quod quis. Rerum sed ut neque sed. Quos praesentium aut deserunt molestias numquam.', 9228.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(194, 'Hic sed deserunt consequatur maxime a consequatur.', 'Et in occaecati reiciendis minima. Velit velit velit pariatur iste. Ut doloremque cupiditate sit aut.', 884.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(195, 'Sed quae sequi non dolorem.', 'Sed consequatur est iure nisi quod. Sunt in et voluptas. Id nemo non earum est nemo nihil cum. Unde aperiam deleniti fugit error recusandae voluptatem.', 8683.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(196, 'Repellat quod beatae accusamus itaque tenetur.', 'Consequatur excepturi iure ipsam. Laborum voluptate adipisci ut expedita.', 7505.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(197, 'Dolorum alias ullam nesciunt.', 'Illum qui fugiat est porro quis sunt et harum. Voluptatem ducimus natus enim quaerat deserunt suscipit. Eos incidunt aut qui nesciunt tempora ea rem. Laboriosam rerum consequatur repellendus.', 3254.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(198, 'Aut aut fugit veniam.', 'Debitis voluptates ex omnis est vel. Unde modi dolores nam voluptatem aliquam est quia. Numquam exercitationem omnis nihil mollitia dolorem iure. Ad ut a quia magni id veritatis officia reprehenderit.', 1376.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(199, 'Nihil odit quo fugit fugiat repellat.', 'Consequatur illo dolorum optio et. Sit ut rem quis quia nihil. Omnis sequi neque omnis veniam fugit harum blanditiis.', 2359.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(200, 'Animi dolores ab similique itaque voluptatem dolorum nesciunt.', 'Culpa quis consectetur dolores odio. Excepturi ratione vel quam exercitationem dolores autem. Exercitationem aut aut repellendus qui.', 2734.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(201, 'Corrupti aperiam nemo cum suscipit consequatur eveniet dolor.', 'Et animi odio sed ratione rem ipsa. Pariatur aperiam rerum accusantium quae magni voluptates et et. Non quidem quam molestiae ullam ut voluptatem aspernatur voluptatem.', 9867.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(202, 'Culpa et nemo ab libero placeat blanditiis.', 'Veniam soluta voluptas fuga ut. Delectus ut quo sunt quos molestias quibusdam enim. Cumque possimus odio animi consequuntur alias sit officia. Dolores inventore eligendi ut.', 2715.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(203, 'Ut eos ea exercitationem suscipit.', 'Amet similique minima quidem corrupti consectetur dolore. Assumenda sunt deleniti accusantium aspernatur rerum. Ea illum dolor non laboriosam et. Corrupti enim qui esse at est.', 6550.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(204, 'Dolorem iste repudiandae quo ut earum nihil.', 'Atque omnis aut tempora quis itaque ut aut natus. Rerum enim eaque eos soluta id modi excepturi.', 2364.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(205, 'Aut accusantium quidem rerum omnis distinctio voluptas.', 'Quam in qui qui velit et totam. Tempora asperiores aut et illo dolorem. Reprehenderit est adipisci numquam cumque.', 5152.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(206, 'Sit aliquam aliquam nesciunt sed sed rerum.', 'Sint sapiente veritatis quod dolorum. Et et ut ut autem repellendus. Doloribus enim sed nemo id dolorem eaque atque.', 4416.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(207, 'Labore qui eos asperiores est dolores voluptatibus.', 'Culpa nihil nam eum veritatis modi corporis est. Nihil nobis aut voluptatum exercitationem rerum. Dolores voluptatum ipsa iure molestiae velit et asperiores ab. Itaque a nihil magni voluptatibus est.', 3471.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(208, 'Aut tenetur voluptatem debitis quaerat voluptatem.', 'Ut rem ut aliquam explicabo temporibus. Eum architecto sed sint sed eos est rem tenetur.', 9763.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(209, 'Tempora molestias consequatur tempora similique corporis vero quasi.', 'Placeat aut recusandae expedita. Autem excepturi dolorum magni asperiores consequatur cum enim. Voluptas distinctio dicta dolore dicta.', 5694.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(210, 'A hic expedita ipsa.', 'Maiores cum numquam ea et. Quaerat est eaque odit non adipisci. Non delectus voluptatem error et officia atque.', 5818.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(211, 'Ipsum architecto ratione totam voluptates quasi repellendus impedit.', 'Omnis dolore ipsam sunt possimus molestias voluptatem. Itaque aliquam quibusdam sunt. Voluptas in consequuntur voluptates dicta.', 7076.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(212, 'Excepturi tenetur sint laboriosam libero earum excepturi.', 'Explicabo quo consequatur qui dicta consequatur et autem. Sint in quasi perferendis. Nulla eos voluptates porro rerum consequatur.', 9241.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(213, 'Deleniti non tempora distinctio vel minima itaque occaecati.', 'Maxime commodi asperiores odio quia. Est id vitae illo et voluptatem deleniti. Molestias aut ipsam maiores voluptatem commodi velit nulla. Nemo minus officiis quasi et.', 7261.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(214, 'Sed vel sunt voluptas dolor saepe eligendi.', 'Minus aut autem autem qui. Architecto est autem perferendis velit. Facilis quisquam illo quia labore animi perferendis non et. Impedit ipsa minima cumque dolores tenetur ipsum. Est veniam earum consequatur est aut.', 3103.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(215, 'Sunt ut est corporis non aspernatur voluptatem suscipit.', 'Velit et dolorum mollitia voluptas nihil. Repellendus quia quibusdam excepturi nesciunt iusto molestiae et. Repudiandae explicabo sed ea et mollitia aut laboriosam. Omnis voluptatem numquam voluptas consequuntur.', 3745.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(216, 'Ad debitis vel nesciunt ad.', 'Delectus eos expedita neque qui suscipit. Quia qui quia exercitationem. Voluptatem aut rerum minus. Magni repudiandae facere necessitatibus illum non. Laboriosam excepturi aliquid sunt nobis facilis.', 8350.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(217, 'Cumque libero iure reiciendis quisquam quia laboriosam omnis est.', 'Minus sit pariatur facilis numquam aperiam nesciunt placeat. Eaque animi cumque eveniet qui sapiente ea. Dolores qui eveniet illo reprehenderit officiis vero.', 6550.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(218, 'Explicabo neque excepturi ab ea et hic ipsum.', 'Sint laudantium doloribus accusamus est alias. Aliquam vel officia ut reiciendis et tenetur rerum sint. Eius aut optio officia qui placeat vero facilis qui. Qui incidunt sit ipsum sit molestias possimus est sapiente.', 8080.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(219, 'Saepe officiis vitae officiis.', 'Earum maxime voluptatem temporibus culpa aut ad perspiciatis quis. Maxime modi sit doloribus. Id deleniti quaerat nesciunt nemo voluptas. Eius rerum debitis distinctio adipisci doloribus.', 5908.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(220, 'Ea deserunt laborum sunt enim vel qui.', 'Nobis vel ut iure itaque. Earum quia accusantium cumque molestiae sed dolor. Rem dignissimos omnis consectetur qui architecto alias. Quis impedit consequatur ullam fugiat.', 1544.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(221, 'Illo molestiae ratione a adipisci.', 'Consequatur sunt illum aut et et. Voluptate sunt ut aut officiis. Sint at qui neque.', 489.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(222, 'Aliquam sint iure sint repellendus odio atque similique.', 'Iusto modi aut velit voluptatem. Distinctio dolores itaque ea omnis reiciendis.', 6040.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(223, 'Ipsam molestiae vel fugit.', 'Dolores autem commodi et explicabo voluptatum rerum. Itaque dignissimos qui praesentium. Labore molestiae rem iste dolore sit.', 3210.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(224, 'Qui nostrum consequatur tempora et nobis.', 'Qui nulla placeat ut necessitatibus nihil itaque et. Et fugiat iure quo sed. Exercitationem facere dicta sint.', 5892.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(225, 'Molestias qui perferendis aut ut consequatur consequatur facilis.', 'Saepe magnam harum amet ut et pariatur et. Impedit aut aspernatur nisi sapiente maiores vel. Deserunt optio consectetur quas nemo consequatur aut numquam. Saepe maxime non voluptas est facilis cumque.', 9703.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(226, 'Nemo sit distinctio vel recusandae non sunt iste minus.', 'Et consequatur explicabo fugit minima sed. Rem quo alias rem quas sequi. Et nulla quae unde consequuntur rerum atque. Dolorem qui aliquid nostrum molestias.', 9801.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(227, 'Quisquam dolor at consequatur porro fuga.', 'Repellat et quia omnis iure. Excepturi voluptates voluptatem expedita assumenda magnam facilis pariatur. Dignissimos alias neque consequatur et ad mollitia. Sed sunt consequuntur consequatur voluptatem.', 4705.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(228, 'Et tempore molestiae aut fuga voluptatibus rerum necessitatibus.', 'Sapiente ut sequi aut sapiente minima nulla sit. Qui ut non voluptas velit natus nesciunt dolor dolor. Cum consequatur iste ea assumenda aliquid saepe. Iste vitae assumenda cumque.', 3753.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(229, 'Eius perspiciatis molestiae iusto magnam in modi.', 'Temporibus recusandae saepe tempore fugit ut et ut. Velit ut non et reiciendis. Commodi error laboriosam vero aut iure eum porro. Sapiente dicta cum omnis quibusdam tempore.', 3223.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(230, 'Impedit ut laborum rem omnis quibusdam cumque voluptatum harum.', 'Omnis necessitatibus corrupti excepturi. Velit enim ut qui voluptatum enim molestiae quia. Nihil voluptate perspiciatis et nostrum. Ea vero neque dolor architecto.', 6681.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(231, 'Et sed est et sed ducimus et quibusdam.', 'Earum ipsum in ullam architecto animi voluptatem minus. Ut necessitatibus repudiandae eum maxime. Sed ea placeat quos maxime quaerat laborum adipisci minima. Commodi quia corporis facilis quas ex quae aliquam facere.', 519.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(232, 'Atque omnis fugiat possimus possimus ea.', 'Velit ducimus error facere explicabo excepturi beatae. Voluptas qui corporis architecto voluptates. Alias consequuntur eos tenetur nihil laudantium et reprehenderit. Et mollitia optio consequatur in animi velit nemo. Rem cupiditate voluptatem minima.', 5159.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(233, 'Sit natus dolor voluptatem.', 'Odio enim distinctio ut. Earum voluptate quisquam iusto voluptas est ea in. Rerum consequatur voluptatem numquam autem.', 2009.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(234, 'Qui aut eos doloremque exercitationem sed delectus.', 'Voluptatem necessitatibus labore dolor omnis illum expedita reprehenderit eveniet. Cumque rerum pariatur aliquid animi minima placeat dignissimos. Numquam aut asperiores est tempore et molestiae. Et quia minima modi nesciunt magni ab et. Doloribus quia veritatis consequuntur et repellendus non et aspernatur.', 8263.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(235, 'Perspiciatis iusto velit dolorem at reiciendis molestias adipisci.', 'Dolores iusto facilis ipsam atque autem fugiat neque. Magnam ducimus doloremque harum et eaque. Sapiente neque quos totam omnis pariatur. Aut ad ab est dolore architecto. Laboriosam hic corrupti cupiditate occaecati quas dolor dolorum.', 9421.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(236, 'Dolor odit aut perspiciatis iste quasi blanditiis voluptatem quis.', 'Velit accusamus nisi omnis aut. Minus est saepe suscipit amet. Deleniti fugit suscipit nihil repudiandae. Quia dolore amet officia eos rerum id.', 8541.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(237, 'Corporis ducimus fugit soluta porro aut.', 'Tenetur voluptatem ut voluptatem harum facilis dolorem. Nulla dolorem fuga sint ut ad qui. Rerum adipisci reiciendis pariatur accusantium eaque expedita.', 2596.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(238, 'Deleniti sit dolores temporibus ratione.', 'Qui blanditiis dolores aut eius minus omnis tempora. Culpa voluptate odio at sit. Ullam in consequuntur ratione voluptatum odio molestiae. Quia voluptas aspernatur nulla aut.', 3454.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(239, 'Commodi dignissimos ipsam hic temporibus.', 'Aspernatur atque sed esse magni dolorum quibusdam. Dolorum et voluptatem architecto fuga iure ipsam saepe labore. Voluptas incidunt error nihil qui nemo est. Sint eum aliquid nobis at pariatur illum.', 3354.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(240, 'Blanditiis modi quae ad ut.', 'Voluptatum aut qui voluptas sint. At alias at ut distinctio cumque. Qui in fugiat dolores possimus.', 793.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(241, 'Deserunt debitis quia doloremque voluptates sed.', 'Quasi quo accusantium laboriosam minus ipsa voluptatem. Dolorem quia eos mollitia voluptas praesentium enim. Nostrum labore sapiente et maxime aut autem et. Accusantium fugit soluta similique dolores voluptatum dolor.', 855.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(242, 'Rem libero voluptas distinctio sunt at qui sint debitis.', 'Labore dicta commodi temporibus id vel non nulla. Alias vel modi nostrum et dolore aut sunt. Ut quibusdam quia reiciendis.', 2644.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(243, 'Ipsum nihil aut et quia.', 'Odio maxime eum eum quidem voluptatibus consequatur vel. Aspernatur sint facere sed perspiciatis blanditiis nesciunt et. Est vel fuga veniam.', 6362.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(244, 'Molestias doloribus aliquam laborum.', 'Nam quaerat et amet eveniet cum officia. Blanditiis voluptatibus dolorum placeat doloribus sunt laborum eligendi. Non occaecati voluptatem est consequatur qui odit. Occaecati doloribus iste eum necessitatibus quia amet nobis.', 8960.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(245, 'Ut nobis est vel ex consequuntur ipsam fuga.', 'Voluptates eveniet alias et perferendis et explicabo. Tenetur commodi nostrum nobis quia nesciunt aliquid quia. Fuga non aut et harum aut.', 5216.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(246, 'Hic numquam modi nihil enim quidem soluta.', 'Natus sed et et dolores sequi quo. Laboriosam eveniet consectetur fugit tempore ut quibusdam vel totam.', 1510.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(247, 'Error qui ipsam facilis natus aut eius.', 'Sequi natus ducimus aut animi optio molestias. Voluptatibus cupiditate eos amet. Laborum dolores blanditiis iste eius placeat eos eius. Velit et repellat quia sunt non eaque cumque.', 7543.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(248, 'Corrupti dolorem est sed vel placeat eos.', 'Consequatur rem cum quasi dolorum. Eum dolorem animi repudiandae necessitatibus exercitationem nostrum. Distinctio ipsum dolorum quidem laboriosam eius.', 6474.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(249, 'Cum eum quis ea quidem facere quia ipsa.', 'Ducimus accusantium tenetur officia labore laudantium dolor. Voluptatem deleniti expedita excepturi ea temporibus quia qui. Consequatur est voluptatum quam tempora asperiores corrupti.', 1373.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(250, 'Dolor nam nesciunt quia sed quod provident aperiam quo.', 'Sed soluta aperiam asperiores impedit sunt. Iure veritatis et aperiam enim. Aliquam non odio cumque commodi. Ut et aspernatur voluptatibus necessitatibus.', 9315.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(251, 'Non doloribus exercitationem officia earum dolores.', 'Suscipit corporis ducimus et ut sed debitis illo. Quisquam omnis ducimus distinctio culpa veritatis consequuntur. Omnis et quis quo ea rerum quis. Impedit deleniti voluptas vel eos ipsum quod culpa.', 6046.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(252, 'Odio nobis maiores dolorum sapiente aut aut suscipit.', 'Consequuntur non laudantium aut repellat. Tenetur commodi sit et fugit. Dolores qui minus velit expedita minus explicabo non voluptas. Quia consequatur ut cum perspiciatis.', 4717.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(253, 'Laboriosam nisi aut nemo ab iure consectetur.', 'Eaque fugiat odio accusantium nihil voluptatem. Ut accusamus totam omnis esse iure. Qui omnis quidem vero necessitatibus tenetur. Laboriosam nulla culpa itaque aperiam non adipisci.', 4748.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(254, 'Et nam sunt ad qui qui velit beatae velit.', 'Ullam sint nobis dolore ducimus. Necessitatibus voluptatem quidem qui eaque.', 346.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(255, 'Mollitia tempora quia ex natus.', 'Illum veniam ut aut at minima. Quo consectetur maiores minima velit. Labore explicabo sit magni qui vitae. Eos et officia nobis qui nostrum. Perferendis voluptatibus minus culpa deleniti excepturi consectetur excepturi.', 9044.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(256, 'Quos labore assumenda cumque molestias.', 'Perferendis quisquam voluptatem expedita in dolore commodi. Ut quisquam rerum quaerat. Dolore atque sint libero debitis. Ad iusto tempore nostrum sed earum ullam quo. Ab quidem mollitia similique rem distinctio nobis voluptatum.', 9575.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(257, 'Ut ut quia non voluptates et aut et.', 'Cupiditate ut aut soluta veritatis. Qui voluptas illum harum. Repellat pariatur dolores asperiores excepturi. Numquam culpa a incidunt rerum natus consequatur.', 3398.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(258, 'Nam odio reiciendis nam autem.', 'Voluptatem nobis veniam accusamus minima voluptas. Sequi dolorem animi sed autem amet quis. Sit sint modi aliquid.', 211.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(259, 'Omnis doloribus est est necessitatibus.', 'Nihil nisi id rem dignissimos quod ipsum. Et suscipit deserunt autem. Voluptatibus voluptatibus et placeat quasi.', 9342.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(260, 'Harum sed maxime molestias corporis quo ut.', 'Vitae in aspernatur molestias velit sed quos et. Ullam voluptatem libero doloribus quae. Amet consequatur et est qui enim iure. Sint quod laboriosam soluta earum quas. Magnam qui delectus omnis est voluptates accusantium.', 5393.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(261, 'Quia et nemo occaecati adipisci natus veniam voluptas.', 'Blanditiis officia quos iste reiciendis magni expedita. Placeat numquam ut voluptatem minima deleniti corrupti repudiandae excepturi. In perspiciatis non aut praesentium numquam possimus nam. Similique corrupti molestiae eveniet expedita voluptatem.', 8097.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(262, 'Velit magnam harum laboriosam eius odit quos libero.', 'Qui quod ipsam et. Nisi in provident deleniti accusamus vitae. Repudiandae optio pariatur praesentium iure dolor. Iste et est expedita voluptas sint.', 9241.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(263, 'Et qui rem dolorem suscipit nihil.', 'Temporibus esse qui ut ducimus neque praesentium. Eaque similique a a odio. Quaerat consequatur blanditiis repellendus dolor voluptatem. Et ullam illum nobis nostrum sint fuga enim fuga.', 6390.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(264, 'Voluptate dolores nemo aut.', 'Deserunt adipisci omnis sit error. Et ex distinctio quis et vel eos. Quisquam et molestiae est ab iusto necessitatibus cumque laudantium.', 1371.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(265, 'Qui perspiciatis explicabo aliquam exercitationem.', 'Perspiciatis quis nulla quae sapiente qui praesentium. Quas et esse magnam veritatis assumenda corrupti. Et et sed et id doloremque et. Voluptatibus sed molestiae harum.', 9209.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(266, 'Consectetur deserunt corporis sint suscipit et porro.', 'Vitae qui ut explicabo. Rerum commodi aspernatur autem enim.', 827.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(267, 'Soluta quia dolorum debitis alias autem.', 'A sint alias soluta et facere. Labore illo optio id molestiae rerum saepe dolore. Rerum quia minima veritatis optio autem vel eveniet harum. Ex nisi occaecati eum ad dolorem molestiae numquam.', 7284.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(268, 'Amet laudantium ut repellat repellat dolores ex quae.', 'Dolor id fugiat voluptas sint in. Dignissimos aut dolorem omnis rerum. Minus labore nisi adipisci aut delectus qui.', 3158.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(269, 'Provident et possimus non quo quod ab consequatur.', 'Facere officia et tenetur. Consectetur voluptatibus neque tempore quia quasi qui. Explicabo tempore dolorum vero. Blanditiis at sed et aperiam beatae exercitationem quibusdam.', 8210.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(270, 'Rem sit et dolore nisi libero.', 'Id facere reprehenderit sunt quo dolorum et dolores. Ut optio et eos at aliquid.', 9404.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(271, 'Voluptatem tenetur facere quas omnis placeat.', 'Quis dolore sit quis aut. Ut harum ipsam voluptas unde doloremque. Reprehenderit voluptas aut iusto est sed.', 9740.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(272, 'Sint aliquam sapiente itaque qui.', 'Atque porro corporis exercitationem fuga non. Autem dolore aliquam aspernatur facilis. Perspiciatis est maiores asperiores cumque qui.', 6365.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(273, 'Et voluptates suscipit modi nihil consequatur.', 'In ut repellendus adipisci. Quia omnis doloremque consequuntur ad repellendus voluptates alias. Vero repudiandae culpa nobis modi debitis odit dolore.', 5784.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(274, 'Incidunt tempora dolores eos debitis sunt.', 'Mollitia omnis non quo veniam. Consequuntur perspiciatis tempora enim cupiditate fugit sed at. Qui magni velit quia corporis qui itaque.', 6298.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(275, 'Et porro et excepturi ullam libero ut ad aperiam.', 'Ducimus in nulla a neque. Id atque neque sequi est nostrum. Sunt voluptas sunt a qui modi doloribus.', 6323.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(276, 'Ex temporibus animi ut quia.', 'Ad ducimus fugit occaecati. Aut dignissimos voluptatem rerum necessitatibus est qui. Blanditiis minus accusamus laborum est minus non assumenda. Voluptatem nesciunt aliquam eum et autem ut sint.', 7792.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(277, 'Voluptatem accusamus quibusdam non enim.', 'Quod eligendi iste voluptates aut. Dolor iure ducimus sint autem. Iure voluptas aperiam minima doloremque velit voluptate dolore. Exercitationem deleniti sint perspiciatis deserunt ut temporibus eos in.', 7601.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(278, 'Quo deleniti officiis numquam tempore debitis aut amet.', 'Cum fuga voluptatum omnis delectus sapiente voluptatem. Quo ut quia qui qui laborum cumque deserunt. Qui qui quia est velit consequuntur sed rerum. Ab laboriosam est autem. Cum voluptas dolorem recusandae porro laborum ullam.', 1167.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(280, 'Consequatur qui harum nisi quo cupiditate.', 'Nihil omnis repellat quas possimus corporis tempora. Quasi pariatur provident voluptatem voluptate perspiciatis. Deserunt fuga doloremque aut minima. Impedit rem rerum exercitationem accusantium.', 5289.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(281, 'Ut consequatur ipsum enim et sit.', 'Tenetur quas ut perspiciatis nulla vitae odio incidunt. Vel sit maiores dolorum ut et ullam. Omnis ipsum animi neque. Deserunt nihil minus vel est ducimus omnis.', 8170.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(282, 'Voluptatem et beatae quia sed totam voluptatem.', 'Iste est ut officia amet odit sequi consequuntur. Quasi exercitationem aspernatur eius possimus. Ad molestiae quam possimus id est. Ut cupiditate alias animi omnis.', 8517.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(283, 'Neque aliquid commodi optio.', 'Id et eius sint id rem aspernatur temporibus soluta. Dolor ipsa et ducimus consectetur est alias hic quidem. Illo accusantium ratione quae. Quasi mollitia in et.', 3162.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(284, 'Quod assumenda est quam ipsa.', 'Quod officia molestiae tempore ut placeat laboriosam qui aspernatur. Et ea voluptatem ad consequuntur. Quisquam dolorum quidem quis voluptas ut.', 9379.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(285, 'Molestias ex veritatis fugiat perferendis alias dolorem.', 'Perspiciatis quos quia unde repudiandae neque debitis aspernatur. Praesentium aut deleniti repudiandae officia et illum commodi. Deleniti voluptatem sint esse earum quaerat voluptatibus ut.', 7270.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(286, 'Ut est odit laborum qui inventore excepturi.', 'Soluta mollitia eos sint dolores voluptates facere unde. Deserunt aut dolor possimus dolor. Dignissimos quibusdam quia recusandae. Enim consequatur sed corporis est commodi corporis.', 5646.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(287, 'Nobis blanditiis voluptas qui.', 'Maiores laudantium dolores quidem quam sit qui voluptas. Sunt nam unde recusandae eos. Corrupti adipisci itaque dolores corrupti ut quam reiciendis. Repudiandae mollitia sint expedita asperiores.', 347.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(288, 'Fuga error at vero.', 'In laudantium et dolorum. Quia voluptatem et saepe quia ut temporibus.', 3833.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(289, 'Suscipit fugiat omnis et maxime culpa rerum eligendi.', 'Id qui vitae deleniti rerum illo. Voluptas sunt aut necessitatibus quia nam corrupti.', 949.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(290, 'Quo sint voluptate aut dolor fugiat et aut provident.', 'Porro et molestiae magnam ut error explicabo quisquam. Dolore cupiditate minima sint perferendis sit voluptatem nam. Qui delectus possimus exercitationem possimus sit ut ullam. Quia iure aut illum aliquam et laboriosam nostrum.', 7014.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(291, 'Iusto qui et aut occaecati quaerat.', 'Ullam provident alias nulla sapiente exercitationem expedita. Autem quo quo similique in atque dolores.', 4144.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(292, 'Dolore delectus sit quam fugiat ab.', 'Saepe error eius iusto sequi inventore accusamus. Maxime voluptatibus delectus qui maxime. Rem perspiciatis minus autem.', 3245.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(293, 'At dolorum accusamus voluptatem debitis rerum sint.', 'Velit quis est ipsum at voluptate vitae laudantium voluptas. Beatae deleniti molestias impedit magnam temporibus non et. Voluptas sed doloremque similique.', 5568.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(294, 'Debitis distinctio nobis quam aut odit.', 'Eum quia laboriosam iste. Ea quas omnis omnis dolores voluptatem est nisi aut. Autem nihil assumenda ut. Et eum unde ut veniam vero similique quo.', 7140.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(295, 'Dicta recusandae velit quod et laudantium.', 'Numquam ut ut iusto asperiores provident aut. Corporis esse vero earum. Porro et quae velit doloremque inventore non.', 7720.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(296, 'Vel similique totam est sunt labore voluptas quia.', 'Accusamus aut earum aut. Nemo nihil officia suscipit sit ut et sit deserunt. Minima atque labore voluptatem quam vel. Vitae quia delectus beatae repudiandae.', 9840.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(297, 'Ut facere magni voluptatibus culpa.', 'Sed cum consequuntur corporis non laborum. Sit et id alias doloremque. Quae sapiente quaerat sapiente libero.', 4058.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(298, 'Laboriosam explicabo aut et atque.', 'Alias ut fugit est. Blanditiis quae accusantium velit praesentium reprehenderit. Totam sit culpa ipsam. Dolores est quia tempore hic voluptatum.', 4062.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(299, 'Labore quibusdam sunt et culpa.', 'Et alias quia alias sunt. Harum ad id eius omnis quod ut enim. Hic ducimus sed et fuga nulla.', 2447.00, 0, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(300, 'Mollitia necessitatibus quia porro molestias.', 'Ratione animi et aspernatur impedit autem. Quisquam rerum maxime quae. Id nesciunt aspernatur molestiae.', 2983.00, 1, '2021-09-01 06:55:06', '2021-09-01 06:55:06'),
(301, 'air mineral', 'air enak sekali', 9000.00, 1, '2021-09-01 07:09:28', '2021-09-01 07:09:28');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_09_01_133606_create_items_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
